<?php
/**
 * Vite development server URL (if available).
 *
 * @package wordpress-plugin
 */

