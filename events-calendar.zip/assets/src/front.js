import './front.scss';

console.log('font.1 loaded!')
console.log('font.2 loaded!')
console.log('font.3 loaded!')
